eventum-commit-log-chrome
=========================

Chrome extension for Eventum: Eventum Commit Log grabs id from the url of the view page, tries to grab the summary and prompts user for a description. Only tested with Eventum 2.1.1
New features version 1.1:
Alerts and prompts removed in favor of extension pop ups.
Update page can now insert a variety useful snippets, such as marking an item complete with the users name.